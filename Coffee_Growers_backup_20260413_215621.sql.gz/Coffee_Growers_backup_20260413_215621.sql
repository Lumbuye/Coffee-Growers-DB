-- MySQL dump 10.13  Distrib 9.6.0, for macos26.2 (arm64)
--
-- Host: 127.0.0.1    Database: Coffee_Growers
-- ------------------------------------------------------
-- Server version	9.2.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `Agro_Chemical`
--

DROP TABLE IF EXISTS `Agro_Chemical`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Agro_Chemical` (
  `input_id` int NOT NULL,
  `chemical_type` enum('Fertilizer','Pesticide','Herbicide','Fungicide') NOT NULL,
  `usage_instructions` text,
  PRIMARY KEY (`input_id`),
  CONSTRAINT `agro_chemical_ibfk_1` FOREIGN KEY (`input_id`) REFERENCES `Input` (`input_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Agro_Chemical`
--

LOCK TABLES `Agro_Chemical` WRITE;
/*!40000 ALTER TABLE `Agro_Chemical` DISABLE KEYS */;
INSERT INTO `Agro_Chemical` VALUES (2,'Fertilizer','Apply around coffee trees as advised; avoid contact with stems.');
/*!40000 ALTER TABLE `Agro_Chemical` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'IGNORE_SPACE,ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `trg_agrochemical_disjoint` BEFORE INSERT ON `agro_chemical` FOR EACH ROW BEGIN
  DECLARE v_type ENUM('Seedling','Agro_Chemical','Machinery');
  SELECT input_type INTO v_type
    FROM Input WHERE input_id = NEW.input_id;
  IF v_type != 'Agro_Chemical' THEN
    SIGNAL SQLSTATE '45000'
      SET MESSAGE_TEXT =
        'Disjoint violation: This input is not typed as Agro_Chemical.';
  END IF;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `CoffeeType`
--

DROP TABLE IF EXISTS `CoffeeType`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `CoffeeType` (
  `type_id` int NOT NULL AUTO_INCREMENT,
  `type_name` enum('Robusta','Arabica') NOT NULL,
  `min_altitude` decimal(7,2) NOT NULL,
  `max_altitude` decimal(7,2) NOT NULL,
  PRIMARY KEY (`type_id`),
  UNIQUE KEY `type_name` (`type_name`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `CoffeeType`
--

LOCK TABLES `CoffeeType` WRITE;
/*!40000 ALTER TABLE `CoffeeType` DISABLE KEYS */;
INSERT INTO `CoffeeType` VALUES (1,'Robusta',900.00,1500.00),(2,'Arabica',1300.00,2300.00);
/*!40000 ALTER TABLE `CoffeeType` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `CoffeeVariety`
--

DROP TABLE IF EXISTS `CoffeeVariety`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `CoffeeVariety` (
  `variety_id` int NOT NULL AUTO_INCREMENT,
  `variety_name` varchar(100) NOT NULL,
  `type_id` int NOT NULL,
  PRIMARY KEY (`variety_id`),
  KEY `type_id` (`type_id`),
  CONSTRAINT `coffeevariety_ibfk_1` FOREIGN KEY (`type_id`) REFERENCES `CoffeeType` (`type_id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `CoffeeVariety`
--

LOCK TABLES `CoffeeVariety` WRITE;
/*!40000 ALTER TABLE `CoffeeVariety` DISABLE KEYS */;
INSERT INTO `CoffeeVariety` VALUES (1,'Nganda',1),(2,'Erecta',1),(3,'Clonal',1),(4,'SL14',2),(5,'SL28',2),(6,'KP423',2),(7,'Nyasaland',2);
/*!40000 ALTER TABLE `CoffeeVariety` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `District`
--

DROP TABLE IF EXISTS `District`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `District` (
  `district_id` int NOT NULL AUTO_INCREMENT,
  `district_name` varchar(100) NOT NULL,
  `region_id` int NOT NULL,
  PRIMARY KEY (`district_id`),
  KEY `region_id` (`region_id`),
  CONSTRAINT `district_ibfk_1` FOREIGN KEY (`region_id`) REFERENCES `Region` (`region_id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `District`
--

LOCK TABLES `District` WRITE;
/*!40000 ALTER TABLE `District` DISABLE KEYS */;
INSERT INTO `District` VALUES (1,'Mukono',1),(2,'Mbarara',2),(3,'Mbale',3),(4,'Kabale',4),(5,'Gulu',5);
/*!40000 ALTER TABLE `District` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Extension_Worker`
--

DROP TABLE IF EXISTS `Extension_Worker`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Extension_Worker` (
  `worker_id` int NOT NULL,
  `employee_id` varchar(20) NOT NULL,
  `hire_date` date NOT NULL,
  `specialization` varchar(100) DEFAULT NULL,
  `assigned_region` varchar(100) DEFAULT NULL,
  `subcounty_id` int DEFAULT NULL,
  PRIMARY KEY (`worker_id`),
  UNIQUE KEY `employee_id` (`employee_id`),
  KEY `subcounty_id` (`subcounty_id`),
  CONSTRAINT `extension_worker_ibfk_1` FOREIGN KEY (`worker_id`) REFERENCES `Person` (`person_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `extension_worker_ibfk_2` FOREIGN KEY (`subcounty_id`) REFERENCES `SubCounty` (`subcounty_id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Extension_Worker`
--

LOCK TABLES `Extension_Worker` WRITE;
/*!40000 ALTER TABLE `Extension_Worker` DISABLE KEYS */;
INSERT INTO `Extension_Worker` VALUES (3,'EXT-001','2021-01-10','Coffee Agronomy','Central',NULL);
/*!40000 ALTER TABLE `Extension_Worker` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'IGNORE_SPACE,ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `trg_worker_disjoint` BEFORE INSERT ON `extension_worker` FOR EACH ROW BEGIN
  DECLARE v_type ENUM('Farmer','Extension_Worker','Ministry_Official');
  SELECT person_type INTO v_type
    FROM Person WHERE person_id = NEW.worker_id;
  IF v_type != 'Extension_Worker' THEN
    SIGNAL SQLSTATE '45000'
      SET MESSAGE_TEXT =
        'Disjoint violation: This person is not typed as Extension_Worker.';
  END IF;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `Farm`
--

DROP TABLE IF EXISTS `Farm`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Farm` (
  `farm_id` int NOT NULL AUTO_INCREMENT,
  `farmer_id` int NOT NULL,
  `farm_name` varchar(100) NOT NULL,
  `farm_size` decimal(8,2) NOT NULL,
  `longitude` varchar(100) DEFAULT NULL,
  `latitude` varchar(100) DEFAULT NULL,
  `altitude` decimal(7,2) NOT NULL,
  `subcounty_id` int NOT NULL,
  PRIMARY KEY (`farm_id`),
  KEY `farmer_id` (`farmer_id`),
  KEY `subcounty_id` (`subcounty_id`),
  CONSTRAINT `farm_ibfk_1` FOREIGN KEY (`farmer_id`) REFERENCES `Farmer` (`farmer_id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `farm_ibfk_2` FOREIGN KEY (`subcounty_id`) REFERENCES `SubCounty` (`subcounty_id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `chk_altitude` CHECK (((`altitude` >= -(500)) and (`altitude` <= 9000))),
  CONSTRAINT `chk_farm_size` CHECK ((`farm_size` > 0))
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Farm`
--

LOCK TABLES `Farm` WRITE;
/*!40000 ALTER TABLE `Farm` DISABLE KEYS */;
INSERT INTO `Farm` VALUES (1,1,'Kato Coffee Garden',2.50,'32.6500','0.3500',1200.00,1),(2,2,'Tumusiime Arabica Hills',3.80,'30.6500','-0.6100',1800.00,3);
/*!40000 ALTER TABLE `Farm` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Farmer`
--

DROP TABLE IF EXISTS `Farmer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Farmer` (
  `farmer_id` int NOT NULL,
  `registration_date` date NOT NULL DEFAULT (curdate()),
  `experience_years` int DEFAULT '0',
  `education_level` enum('None','Primary','Secondary','Tertiary') DEFAULT NULL,
  `management_level` enum('Traditional','Improved','Recommended','Estate') NOT NULL,
  `subcounty_id` int NOT NULL,
  PRIMARY KEY (`farmer_id`),
  KEY `subcounty_id` (`subcounty_id`),
  CONSTRAINT `farmer_ibfk_1` FOREIGN KEY (`farmer_id`) REFERENCES `Person` (`person_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `farmer_ibfk_2` FOREIGN KEY (`subcounty_id`) REFERENCES `SubCounty` (`subcounty_id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `chk_experience` CHECK (((`experience_years` >= 0) and (`experience_years` <= 60)))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Farmer`
--

LOCK TABLES `Farmer` WRITE;
/*!40000 ALTER TABLE `Farmer` DISABLE KEYS */;
INSERT INTO `Farmer` VALUES (1,'2026-04-12',5,'Secondary','Improved',1),(2,'2026-04-12',8,'Tertiary','Recommended',3);
/*!40000 ALTER TABLE `Farmer` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'IGNORE_SPACE,ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `trg_farmer_disjoint` BEFORE INSERT ON `farmer` FOR EACH ROW BEGIN
  DECLARE v_type ENUM('Farmer','Extension_Worker','Ministry_Official');
  SELECT person_type INTO v_type
    FROM Person WHERE person_id = NEW.farmer_id;
  IF v_type != 'Farmer' THEN
    SIGNAL SQLSTATE '45000'
      SET MESSAGE_TEXT =
        'Disjoint violation: This person is not typed as Farmer.';
  END IF;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `FarmVisit`
--

DROP TABLE IF EXISTS `FarmVisit`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `FarmVisit` (
  `visit_id` int NOT NULL AUTO_INCREMENT,
  `farm_id` int NOT NULL,
  `worker_id` int NOT NULL,
  `visit_date` date NOT NULL,
  `purpose` enum('Advisory','Monitoring','Training') NOT NULL,
  `observations` text,
  `followup_date` date DEFAULT NULL,
  PRIMARY KEY (`visit_id`),
  KEY `farm_id` (`farm_id`),
  KEY `worker_id` (`worker_id`),
  CONSTRAINT `farmvisit_ibfk_1` FOREIGN KEY (`farm_id`) REFERENCES `Farm` (`farm_id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `farmvisit_ibfk_2` FOREIGN KEY (`worker_id`) REFERENCES `Extension_Worker` (`worker_id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `chk_followup` CHECK (((`followup_date` is null) or (`followup_date` > `visit_date`)))
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `FarmVisit`
--

LOCK TABLES `FarmVisit` WRITE;
/*!40000 ALTER TABLE `FarmVisit` DISABLE KEYS */;
INSERT INTO `FarmVisit` VALUES (1,1,3,'2025-03-25','Advisory','Advised on pruning and mulching; recommended proper spacing for new seedlings.','2025-04-25'),(2,1,3,'2025-04-28','Monitoring','Checked seedling survival rate; advised pest scouting after rains.',NULL);
/*!40000 ALTER TABLE `FarmVisit` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Input`
--

DROP TABLE IF EXISTS `Input`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Input` (
  `input_id` int NOT NULL AUTO_INCREMENT,
  `input_name` varchar(150) NOT NULL,
  `input_type` enum('Seedling','Agro_Chemical','Machinery') NOT NULL,
  `unit` varchar(50) NOT NULL,
  PRIMARY KEY (`input_id`),
  CONSTRAINT `chk_input_name_length` CHECK ((length(trim(`input_name`)) > 0))
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Input`
--

LOCK TABLES `Input` WRITE;
/*!40000 ALTER TABLE `Input` DISABLE KEYS */;
INSERT INTO `Input` VALUES (1,'Coffee Seedlings Batch A','Seedling','seedlings'),(2,'NPK Fertilizer 25kg','Agro_Chemical','kg'),(3,'Pruning Shears','Machinery','pieces');
/*!40000 ALTER TABLE `Input` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `InputDistribution`
--

DROP TABLE IF EXISTS `InputDistribution`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `InputDistribution` (
  `distribution_id` int NOT NULL AUTO_INCREMENT,
  `farm_id` int NOT NULL,
  `worker_id` int NOT NULL,
  `input_id` int NOT NULL,
  `quantity` decimal(10,2) NOT NULL,
  `date_issued` date NOT NULL,
  `season_id` int NOT NULL,
  PRIMARY KEY (`distribution_id`),
  KEY `input_id` (`input_id`),
  KEY `worker_id` (`worker_id`),
  KEY `farm_id` (`farm_id`),
  KEY `season_id` (`season_id`),
  CONSTRAINT `inputdistribution_ibfk_1` FOREIGN KEY (`input_id`) REFERENCES `input` (`input_id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `inputdistribution_ibfk_2` FOREIGN KEY (`worker_id`) REFERENCES `Extension_Worker` (`worker_id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `inputdistribution_ibfk_3` FOREIGN KEY (`farm_id`) REFERENCES `Farm` (`farm_id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `inputdistribution_ibfk_4` FOREIGN KEY (`season_id`) REFERENCES `Season` (`season_id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `chk_quantity_positive` CHECK ((`quantity` > 0))
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `InputDistribution`
--

LOCK TABLES `InputDistribution` WRITE;
/*!40000 ALTER TABLE `InputDistribution` DISABLE KEYS */;
INSERT INTO `InputDistribution` VALUES (1,1,3,1,200.00,'2025-03-20',1),(2,1,3,2,50.00,'2025-04-10',1),(3,2,3,2,75.00,'2025-04-15',1),(4,2,3,3,5.00,'2025-05-02',1);
/*!40000 ALTER TABLE `InputDistribution` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Machinery`
--

DROP TABLE IF EXISTS `Machinery`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Machinery` (
  `input_id` int NOT NULL,
  `machinery_type` varchar(100) NOT NULL,
  `model` varchar(100) DEFAULT NULL,
  `machine_condition` enum('New','Good','Fair','Poor') NOT NULL DEFAULT 'Good',
  PRIMARY KEY (`input_id`),
  CONSTRAINT `machinery_ibfk_1` FOREIGN KEY (`input_id`) REFERENCES `Input` (`input_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Machinery`
--

LOCK TABLES `Machinery` WRITE;
/*!40000 ALTER TABLE `Machinery` DISABLE KEYS */;
INSERT INTO `Machinery` VALUES (3,'Hand Tool','Standard Pruner','Good');
/*!40000 ALTER TABLE `Machinery` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'IGNORE_SPACE,ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `trg_machinery_disjoint` BEFORE INSERT ON `machinery` FOR EACH ROW BEGIN
  DECLARE v_type ENUM('Seedling','Agro_Chemical','Machinery');
  SELECT input_type INTO v_type
    FROM Input WHERE input_id = NEW.input_id;
  IF v_type != 'Machinery' THEN
    SIGNAL SQLSTATE '45000'
      SET MESSAGE_TEXT =
        'Disjoint violation: This input is not typed as Machinery.';
  END IF;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `Ministry_Official`
--

DROP TABLE IF EXISTS `Ministry_Official`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Ministry_Official` (
  `official_id` int NOT NULL,
  `employee_id` varchar(20) NOT NULL,
  `department` varchar(100) NOT NULL,
  `position` varchar(100) NOT NULL,
  PRIMARY KEY (`official_id`),
  UNIQUE KEY `employee_id` (`employee_id`),
  CONSTRAINT `ministry_official_ibfk_1` FOREIGN KEY (`official_id`) REFERENCES `Person` (`person_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Ministry_Official`
--

LOCK TABLES `Ministry_Official` WRITE;
/*!40000 ALTER TABLE `Ministry_Official` DISABLE KEYS */;
INSERT INTO `Ministry_Official` VALUES (4,'MOA-010','Coffee Development','Program Officer');
/*!40000 ALTER TABLE `Ministry_Official` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'IGNORE_SPACE,ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `trg_official_disjoint` BEFORE INSERT ON `ministry_official` FOR EACH ROW BEGIN
  DECLARE v_type ENUM('Farmer','Extension_Worker','Ministry_Official');
  SELECT person_type INTO v_type
    FROM Person WHERE person_id = NEW.official_id;
  IF v_type != 'Ministry_Official' THEN
    SIGNAL SQLSTATE '45000'
      SET MESSAGE_TEXT =
        'Disjoint violation: This person is not typed as Ministry_Official.';
  END IF;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `Person`
--

DROP TABLE IF EXISTS `Person`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Person` (
  `person_id` int NOT NULL AUTO_INCREMENT,
  `person_name` varchar(150) NOT NULL,
  `person_contact` varchar(15) DEFAULT NULL,
  `national_id` varchar(20) NOT NULL,
  `date_of_birth` date NOT NULL,
  `person_type` enum('Farmer','Extension_Worker','Ministry_Official') NOT NULL,
  PRIMARY KEY (`person_id`),
  UNIQUE KEY `national_id` (`national_id`),
  CONSTRAINT `chk_contact_format` CHECK (regexp_like(`person_contact`,_utf8mb4'^[0-9+]{10,15}$'))
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Person`
--

LOCK TABLES `Person` WRITE;
/*!40000 ALTER TABLE `Person` DISABLE KEYS */;
INSERT INTO `Person` VALUES (1,'Amon Kato','0772123456','CM90001234567A','1988-06-20','Farmer'),(2,'Grace Tumusiime','0788123456','CF94000987654B','1994-11-12','Farmer'),(3,'John K. Ssemakula','0700123456','CM88000111222C','1986-02-05','Extension_Worker'),(4,'Sarah N. Nabirye','0755123456','CF87000123456D','1987-08-19','Ministry_Official'),(5,'Test Farmer','0711111111','TEST-NIN-0002','1992-02-02','Farmer');
/*!40000 ALTER TABLE `Person` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Production`
--

DROP TABLE IF EXISTS `Production`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Production` (
  `production_id` int NOT NULL AUTO_INCREMENT,
  `farm_id` int NOT NULL,
  `variety_id` int NOT NULL,
  `season_id` int NOT NULL,
  `yield_kg` decimal(10,2) NOT NULL,
  `harvest_date` date NOT NULL,
  PRIMARY KEY (`production_id`),
  UNIQUE KEY `farm_id` (`farm_id`,`variety_id`,`season_id`),
  KEY `variety_id` (`variety_id`),
  KEY `season_id` (`season_id`),
  CONSTRAINT `production_ibfk_1` FOREIGN KEY (`farm_id`) REFERENCES `Farm` (`farm_id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `production_ibfk_2` FOREIGN KEY (`variety_id`) REFERENCES `CoffeeVariety` (`variety_id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `production_ibfk_3` FOREIGN KEY (`season_id`) REFERENCES `Season` (`season_id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `chk_yield_positive` CHECK ((`yield_kg` >= 0))
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Production`
--

LOCK TABLES `Production` WRITE;
/*!40000 ALTER TABLE `Production` DISABLE KEYS */;
INSERT INTO `Production` VALUES (1,1,1,1,1500.00,'2025-10-15'),(2,2,5,1,1200.00,'2025-10-20');
/*!40000 ALTER TABLE `Production` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Project`
--

DROP TABLE IF EXISTS `Project`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Project` (
  `project_id` int NOT NULL AUTO_INCREMENT,
  `farmer_id` int NOT NULL,
  `project_name` varchar(150) NOT NULL,
  `total_cost` decimal(12,2) NOT NULL DEFAULT '0.00',
  `govt_contribution` decimal(12,2) NOT NULL DEFAULT '0.00',
  `official_id` int NOT NULL,
  `start_date` date NOT NULL,
  `status` enum('Planned','Ongoing','Completed','Cancelled') NOT NULL DEFAULT 'Planned',
  PRIMARY KEY (`project_id`),
  KEY `farmer_id` (`farmer_id`),
  KEY `official_id` (`official_id`),
  CONSTRAINT `project_ibfk_1` FOREIGN KEY (`farmer_id`) REFERENCES `Farmer` (`farmer_id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `project_ibfk_2` FOREIGN KEY (`official_id`) REFERENCES `Ministry_Official` (`official_id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `chk_govt_contrib_logic` CHECK ((`govt_contribution` <= `total_cost`)),
  CONSTRAINT `chk_project_costs` CHECK (((`total_cost` >= 0) and (`govt_contribution` >= 0)))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Project`
--

LOCK TABLES `Project` WRITE;
/*!40000 ALTER TABLE `Project` DISABLE KEYS */;
/*!40000 ALTER TABLE `Project` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Region`
--

DROP TABLE IF EXISTS `Region`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Region` (
  `region_id` int NOT NULL AUTO_INCREMENT,
  `region_name` varchar(50) NOT NULL,
  PRIMARY KEY (`region_id`),
  UNIQUE KEY `region_name` (`region_name`),
  CONSTRAINT `chk_region` CHECK ((`region_name` in (_utf8mb4'Central',_utf8mb4'Eastern',_utf8mb4'Western',_utf8mb4'South-Western',_utf8mb4'Northern')))
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Region`
--

LOCK TABLES `Region` WRITE;
/*!40000 ALTER TABLE `Region` DISABLE KEYS */;
INSERT INTO `Region` VALUES (1,'Central'),(3,'Eastern'),(5,'Northern'),(4,'South-Western'),(2,'Western');
/*!40000 ALTER TABLE `Region` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Report`
--

DROP TABLE IF EXISTS `Report`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Report` (
  `report_id` int NOT NULL AUTO_INCREMENT,
  `farm_id` int NOT NULL,
  `worker_id` int NOT NULL,
  `report_date` date NOT NULL,
  PRIMARY KEY (`report_id`),
  KEY `farm_id` (`farm_id`),
  KEY `worker_id` (`worker_id`),
  CONSTRAINT `report_ibfk_1` FOREIGN KEY (`farm_id`) REFERENCES `Farm` (`farm_id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `report_ibfk_2` FOREIGN KEY (`worker_id`) REFERENCES `Extension_Worker` (`worker_id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Report`
--

LOCK TABLES `Report` WRITE;
/*!40000 ALTER TABLE `Report` DISABLE KEYS */;
/*!40000 ALTER TABLE `Report` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Season`
--

DROP TABLE IF EXISTS `Season`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Season` (
  `season_id` int NOT NULL AUTO_INCREMENT,
  `season_name` varchar(50) NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  PRIMARY KEY (`season_id`),
  CONSTRAINT `chk_season_dates` CHECK ((`end_date` > `start_date`))
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Season`
--

LOCK TABLES `Season` WRITE;
/*!40000 ALTER TABLE `Season` DISABLE KEYS */;
INSERT INTO `Season` VALUES (1,'2025 Main Season','2025-03-01','2025-08-31'),(2,'2025 Fly Season','2025-09-01','2026-02-28');
/*!40000 ALTER TABLE `Season` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Seedling`
--

DROP TABLE IF EXISTS `Seedling`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Seedling` (
  `input_id` int NOT NULL,
  `variety` varchar(100) NOT NULL,
  `age_in_weeks` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`input_id`),
  CONSTRAINT `seedling_ibfk_1` FOREIGN KEY (`input_id`) REFERENCES `Input` (`input_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `chk_age_positive` CHECK (((`age_in_weeks` >= 0) and (`age_in_weeks` <= 104))),
  CONSTRAINT `chk_seedling_variety` CHECK ((`variety` in (_utf8mb4'Nganda',_utf8mb4'Erecta',_utf8mb4'Clonal',_utf8mb4'SL14',_utf8mb4'SL28',_utf8mb4'KP423',_utf8mb4'Nyasaland')))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Seedling`
--

LOCK TABLES `Seedling` WRITE;
/*!40000 ALTER TABLE `Seedling` DISABLE KEYS */;
INSERT INTO `Seedling` VALUES (1,'Nganda',6);
/*!40000 ALTER TABLE `Seedling` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'IGNORE_SPACE,ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `trg_seedling_disjoint` BEFORE INSERT ON `seedling` FOR EACH ROW BEGIN
  DECLARE v_type ENUM('Seedling','Agro_Chemical','Machinery');
  SELECT input_type INTO v_type
    FROM Input WHERE input_id = NEW.input_id;
  IF v_type != 'Seedling' THEN
    SIGNAL SQLSTATE '45000'
      SET MESSAGE_TEXT =
        'Disjoint violation: This input is not typed as Seedling.';
  END IF;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `SubCounty`
--

DROP TABLE IF EXISTS `SubCounty`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `SubCounty` (
  `subcounty_id` int NOT NULL AUTO_INCREMENT,
  `subcounty_name` varchar(100) NOT NULL,
  `district_id` int NOT NULL,
  PRIMARY KEY (`subcounty_id`),
  KEY `district_id` (`district_id`),
  CONSTRAINT `subcounty_ibfk_1` FOREIGN KEY (`district_id`) REFERENCES `District` (`district_id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SubCounty`
--

LOCK TABLES `SubCounty` WRITE;
/*!40000 ALTER TABLE `SubCounty` DISABLE KEYS */;
INSERT INTO `SubCounty` VALUES (1,'Seeta',1),(2,'Mukono TC',1),(3,'Nyamitanga',2),(4,'Mbale TC',3),(5,'Kabale TC',4),(6,'Gulu TC',5);
/*!40000 ALTER TABLE `SubCounty` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `User_Accounts`
--

DROP TABLE IF EXISTS `User_Accounts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `User_Accounts` (
  `account_id` int NOT NULL AUTO_INCREMENT,
  `person_id` int NOT NULL,
  `username` varchar(50) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `role` enum('Farmer','Extension_Worker','Ministry_Official','Admin') NOT NULL,
  `account_status` enum('Active','Inactive','Suspended') NOT NULL DEFAULT 'Active',
  `last_login` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`account_id`),
  UNIQUE KEY `person_id` (`person_id`),
  UNIQUE KEY `username` (`username`),
  CONSTRAINT `user_accounts_ibfk_1` FOREIGN KEY (`person_id`) REFERENCES `Person` (`person_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `chk_password_hashed` CHECK ((length(`password_hash`) >= 60)),
  CONSTRAINT `chk_username_length` CHECK ((length(`username`) >= 4))
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `User_Accounts`
--

LOCK TABLES `User_Accounts` WRITE;
/*!40000 ALTER TABLE `User_Accounts` DISABLE KEYS */;
INSERT INTO `User_Accounts` VALUES (1,1,'amon.kato','9e890294708ac4b37d4864c7187ffbaf095e34dbac40afb98c53b7cc66643c2e','Farmer','Active',NULL,'2026-04-12 18:51:35'),(2,3,'ew.john','9e890294708ac4b37d4864c7187ffbaf095e34dbac40afb98c53b7cc66643c2e','Extension_Worker','Active',NULL,'2026-04-12 18:51:35'),(3,4,'min.officer1','9e890294708ac4b37d4864c7187ffbaf095e34dbac40afb98c53b7cc66643c2e','Ministry_Official','Active',NULL,'2026-04-12 18:51:35');
/*!40000 ALTER TABLE `User_Accounts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary view structure for view `v_extension_assigned_farms`
--

DROP TABLE IF EXISTS `v_extension_assigned_farms`;
/*!50001 DROP VIEW IF EXISTS `v_extension_assigned_farms`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `v_extension_assigned_farms` AS SELECT 
 1 AS `farm_id`,
 1 AS `farm_name`,
 1 AS `farm_size`,
 1 AS `altitude`,
 1 AS `subcounty_name`,
 1 AS `district_name`,
 1 AS `region_name`,
 1 AS `farmer_name`,
 1 AS `person_contact`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `v_extension_my_visits`
--

DROP TABLE IF EXISTS `v_extension_my_visits`;
/*!50001 DROP VIEW IF EXISTS `v_extension_my_visits`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `v_extension_my_visits` AS SELECT 
 1 AS `visit_id`,
 1 AS `farm_id`,
 1 AS `farm_name`,
 1 AS `visit_date`,
 1 AS `purpose`,
 1 AS `observations`,
 1 AS `followup_date`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `v_farmer_farms`
--

DROP TABLE IF EXISTS `v_farmer_farms`;
/*!50001 DROP VIEW IF EXISTS `v_farmer_farms`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `v_farmer_farms` AS SELECT 
 1 AS `farm_id`,
 1 AS `farmer_id`,
 1 AS `farm_name`,
 1 AS `farm_size`,
 1 AS `longitude`,
 1 AS `latitude`,
 1 AS `altitude`,
 1 AS `subcounty_id`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `v_farmer_inputs`
--

DROP TABLE IF EXISTS `v_farmer_inputs`;
/*!50001 DROP VIEW IF EXISTS `v_farmer_inputs`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `v_farmer_inputs` AS SELECT 
 1 AS `distribution_id`,
 1 AS `farm_id`,
 1 AS `farm_name`,
 1 AS `input_name`,
 1 AS `input_type`,
 1 AS `quantity`,
 1 AS `unit`,
 1 AS `season_name`,
 1 AS `date_issued`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `v_farmer_production`
--

DROP TABLE IF EXISTS `v_farmer_production`;
/*!50001 DROP VIEW IF EXISTS `v_farmer_production`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `v_farmer_production` AS SELECT 
 1 AS `production_id`,
 1 AS `farm_id`,
 1 AS `farm_name`,
 1 AS `variety_name`,
 1 AS `type_name`,
 1 AS `season_name`,
 1 AS `yield_kg`,
 1 AS `harvest_date`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `v_farmer_profile`
--

DROP TABLE IF EXISTS `v_farmer_profile`;
/*!50001 DROP VIEW IF EXISTS `v_farmer_profile`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `v_farmer_profile` AS SELECT 
 1 AS `person_id`,
 1 AS `person_name`,
 1 AS `person_contact`,
 1 AS `national_id`,
 1 AS `date_of_birth`,
 1 AS `registration_date`,
 1 AS `experience_years`,
 1 AS `education_level`,
 1 AS `management_level`,
 1 AS `subcounty_name`,
 1 AS `district_name`,
 1 AS `region_name`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `v_farmer_visits`
--

DROP TABLE IF EXISTS `v_farmer_visits`;
/*!50001 DROP VIEW IF EXISTS `v_farmer_visits`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `v_farmer_visits` AS SELECT 
 1 AS `visit_id`,
 1 AS `farm_id`,
 1 AS `farm_name`,
 1 AS `visit_date`,
 1 AS `purpose`,
 1 AS `observations`,
 1 AS `followup_date`,
 1 AS `extension_employee_id`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `v_ministry_production_summary`
--

DROP TABLE IF EXISTS `v_ministry_production_summary`;
/*!50001 DROP VIEW IF EXISTS `v_ministry_production_summary`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `v_ministry_production_summary` AS SELECT 
 1 AS `region_name`,
 1 AS `district_name`,
 1 AS `subcounty_name`,
 1 AS `type_name`,
 1 AS `variety_name`,
 1 AS `season_name`,
 1 AS `total_yield_kg`,
 1 AS `farms_reported`*/;
SET character_set_client = @saved_cs_client;

--
-- Final view structure for view `v_extension_assigned_farms`
--

/*!50001 DROP VIEW IF EXISTS `v_extension_assigned_farms`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_extension_assigned_farms` AS select `fa`.`farm_id` AS `farm_id`,`fa`.`farm_name` AS `farm_name`,`fa`.`farm_size` AS `farm_size`,`fa`.`altitude` AS `altitude`,`sc`.`subcounty_name` AS `subcounty_name`,`d`.`district_name` AS `district_name`,`r`.`region_name` AS `region_name`,`p`.`person_name` AS `farmer_name`,`p`.`person_contact` AS `person_contact` from (((((((`user_accounts` `ua` join `extension_worker` `ew` on((`ew`.`worker_id` = `ua`.`person_id`))) join `farm` `fa` on((`fa`.`subcounty_id` = `ew`.`subcounty_id`))) join `farmer` `f` on((`f`.`farmer_id` = `fa`.`farmer_id`))) join `person` `p` on((`p`.`person_id` = `f`.`farmer_id`))) join `subcounty` `sc` on((`sc`.`subcounty_id` = `fa`.`subcounty_id`))) join `district` `d` on((`d`.`district_id` = `sc`.`district_id`))) join `region` `r` on((`r`.`region_id` = `d`.`region_id`))) where (`ua`.`username` = substring_index(current_user(),'@',1)) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_extension_my_visits`
--

/*!50001 DROP VIEW IF EXISTS `v_extension_my_visits`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_extension_my_visits` AS select `fv`.`visit_id` AS `visit_id`,`fv`.`farm_id` AS `farm_id`,`fa`.`farm_name` AS `farm_name`,`fv`.`visit_date` AS `visit_date`,`fv`.`purpose` AS `purpose`,`fv`.`observations` AS `observations`,`fv`.`followup_date` AS `followup_date` from (((`user_accounts` `ua` join `extension_worker` `ew` on((`ew`.`worker_id` = `ua`.`person_id`))) join `farmvisit` `fv` on((`fv`.`worker_id` = `ew`.`worker_id`))) join `farm` `fa` on((`fa`.`farm_id` = `fv`.`farm_id`))) where (`ua`.`username` = substring_index(current_user(),'@',1)) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_farmer_farms`
--

/*!50001 DROP VIEW IF EXISTS `v_farmer_farms`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_farmer_farms` AS select `fa`.`farm_id` AS `farm_id`,`fa`.`farmer_id` AS `farmer_id`,`fa`.`farm_name` AS `farm_name`,`fa`.`farm_size` AS `farm_size`,`fa`.`longitude` AS `longitude`,`fa`.`latitude` AS `latitude`,`fa`.`altitude` AS `altitude`,`fa`.`subcounty_id` AS `subcounty_id` from ((`user_accounts` `ua` join `farmer` `f` on((`f`.`farmer_id` = `ua`.`person_id`))) join `farm` `fa` on((`fa`.`farmer_id` = `f`.`farmer_id`))) where (`ua`.`username` = substring_index(current_user(),'@',1)) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_farmer_inputs`
--

/*!50001 DROP VIEW IF EXISTS `v_farmer_inputs`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_farmer_inputs` AS select `id`.`distribution_id` AS `distribution_id`,`id`.`farm_id` AS `farm_id`,`fa`.`farm_name` AS `farm_name`,`i`.`input_name` AS `input_name`,`i`.`input_type` AS `input_type`,`id`.`quantity` AS `quantity`,`i`.`unit` AS `unit`,`s`.`season_name` AS `season_name`,`id`.`date_issued` AS `date_issued` from (((((`user_accounts` `ua` join `farmer` `f` on((`f`.`farmer_id` = `ua`.`person_id`))) join `farm` `fa` on((`fa`.`farmer_id` = `f`.`farmer_id`))) join `inputdistribution` `id` on((`id`.`farm_id` = `fa`.`farm_id`))) join `input` `i` on((`i`.`input_id` = `id`.`input_id`))) join `season` `s` on((`s`.`season_id` = `id`.`season_id`))) where (`ua`.`username` = substring_index(current_user(),'@',1)) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_farmer_production`
--

/*!50001 DROP VIEW IF EXISTS `v_farmer_production`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_farmer_production` AS select `pr`.`production_id` AS `production_id`,`pr`.`farm_id` AS `farm_id`,`fa`.`farm_name` AS `farm_name`,`cv`.`variety_name` AS `variety_name`,`ct`.`type_name` AS `type_name`,`s`.`season_name` AS `season_name`,`pr`.`yield_kg` AS `yield_kg`,`pr`.`harvest_date` AS `harvest_date` from ((((((`user_accounts` `ua` join `farmer` `f` on((`f`.`farmer_id` = `ua`.`person_id`))) join `farm` `fa` on((`fa`.`farmer_id` = `f`.`farmer_id`))) join `production` `pr` on((`pr`.`farm_id` = `fa`.`farm_id`))) join `coffeevariety` `cv` on((`cv`.`variety_id` = `pr`.`variety_id`))) join `coffeetype` `ct` on((`ct`.`type_id` = `cv`.`type_id`))) join `season` `s` on((`s`.`season_id` = `pr`.`season_id`))) where (`ua`.`username` = substring_index(current_user(),'@',1)) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_farmer_profile`
--

/*!50001 DROP VIEW IF EXISTS `v_farmer_profile`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_farmer_profile` AS select `p`.`person_id` AS `person_id`,`p`.`person_name` AS `person_name`,`p`.`person_contact` AS `person_contact`,`p`.`national_id` AS `national_id`,`p`.`date_of_birth` AS `date_of_birth`,`f`.`registration_date` AS `registration_date`,`f`.`experience_years` AS `experience_years`,`f`.`education_level` AS `education_level`,`f`.`management_level` AS `management_level`,`sc`.`subcounty_name` AS `subcounty_name`,`d`.`district_name` AS `district_name`,`r`.`region_name` AS `region_name` from (((((`user_accounts` `ua` join `person` `p` on((`p`.`person_id` = `ua`.`person_id`))) join `farmer` `f` on((`f`.`farmer_id` = `ua`.`person_id`))) join `subcounty` `sc` on((`sc`.`subcounty_id` = `f`.`subcounty_id`))) join `district` `d` on((`d`.`district_id` = `sc`.`district_id`))) join `region` `r` on((`r`.`region_id` = `d`.`region_id`))) where (`ua`.`username` = substring_index(current_user(),'@',1)) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_farmer_visits`
--

/*!50001 DROP VIEW IF EXISTS `v_farmer_visits`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_farmer_visits` AS select `fv`.`visit_id` AS `visit_id`,`fv`.`farm_id` AS `farm_id`,`fa`.`farm_name` AS `farm_name`,`fv`.`visit_date` AS `visit_date`,`fv`.`purpose` AS `purpose`,`fv`.`observations` AS `observations`,`fv`.`followup_date` AS `followup_date`,`ew`.`employee_id` AS `extension_employee_id` from ((((`user_accounts` `ua` join `farmer` `f` on((`f`.`farmer_id` = `ua`.`person_id`))) join `farm` `fa` on((`fa`.`farmer_id` = `f`.`farmer_id`))) join `farmvisit` `fv` on((`fv`.`farm_id` = `fa`.`farm_id`))) join `extension_worker` `ew` on((`ew`.`worker_id` = `fv`.`worker_id`))) where (`ua`.`username` = substring_index(current_user(),'@',1)) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_ministry_production_summary`
--

/*!50001 DROP VIEW IF EXISTS `v_ministry_production_summary`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_ministry_production_summary` AS select `r`.`region_name` AS `region_name`,`d`.`district_name` AS `district_name`,`sc`.`subcounty_name` AS `subcounty_name`,`ct`.`type_name` AS `type_name`,`cv`.`variety_name` AS `variety_name`,`s`.`season_name` AS `season_name`,sum(`pr`.`yield_kg`) AS `total_yield_kg`,count(distinct `pr`.`farm_id`) AS `farms_reported` from (((((((`production` `pr` join `farm` `fa` on((`fa`.`farm_id` = `pr`.`farm_id`))) join `subcounty` `sc` on((`sc`.`subcounty_id` = `fa`.`subcounty_id`))) join `district` `d` on((`d`.`district_id` = `sc`.`district_id`))) join `region` `r` on((`r`.`region_id` = `d`.`region_id`))) join `coffeevariety` `cv` on((`cv`.`variety_id` = `pr`.`variety_id`))) join `coffeetype` `ct` on((`ct`.`type_id` = `cv`.`type_id`))) join `season` `s` on((`s`.`season_id` = `pr`.`season_id`))) group by `r`.`region_name`,`d`.`district_name`,`sc`.`subcounty_name`,`ct`.`type_name`,`cv`.`variety_name`,`s`.`season_name` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-04-13 21:56:22
